"residuals.mmpp" <-
function (object, ...) 
{
    stop("Generic function 'residuals' has no method yet for 'mmpp'.")
}

