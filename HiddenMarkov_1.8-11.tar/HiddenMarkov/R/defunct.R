"residualshmm" <-
function (x, Pi, delta, distn, pm, pn = NULL, discrete = FALSE) 
{
    .Defunct("residuals", package="HiddenMarkov",
          msg="'residualshmm' is deprecated.
          Use 'residuals' instead, see help('residuals').")
}


