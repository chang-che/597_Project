"Viterbi.mmpp" <-
function (object, ...) 
{
    stop("Generic function 'Viterbi' has no method yet for 'mmpp'.")
}

